﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class Sprite
    {
        public String front_default { get; set; }
        public String front_shiny { get; set; }
        public String front_female { get; set; }
        public String front_shiny_female { get; set; }
        public String back_default { get; set; }
        public String back_shiny { get; set; }
        public String back_female { get; set; }
        public String back_shiny_female { get; set; }
    }
}
