﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class Type
    {
        public String name { get; set; }
        public String url { get; set; }
    }
}
