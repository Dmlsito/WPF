﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RestSharp;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        String pokemon;
        List<Pokemon> listaPokemon;
        String UrlPokemon = "https://pokeapi.co/api/v2/pokemon";
       
        
        public MainWindow()
        {
            InitializeComponent();
           
        }
        private void recuperarDatoConcreto()
        {
            var client = new RestClient(UrlPokemon);
            var request = new RestRequest("/" + pokemon, Method.GET);

            listaPokemon = client.Execute<List<Pokemon>>(request).Data;
            try {
                //Si el usuario escribe un pokemon mal la lista sera null y se lanzara una excepcion que la capturara el catch 
                if(listaPokemon == null) throw new Exception();
                
                foreach (Pokemon pokemon in listaPokemon){
                    
                    //Ahora añadimos a los campos los datos recogidos de la api
                    name.Text = pokemon.name;
                    baseExperience.Text = pokemon.base_experience.ToString();
                    height.Text = pokemon.height.ToString();
                    isDefault.Text = pokemon.is_Default.ToString();
                    order.Text = pokemon.order.ToString();
                    weight.Text = pokemon.weight.ToString();
                    //Obtenemos la imagen del pokemon
                    imagePokemon.Source = new BitmapImage(new Uri(pokemon.sprites.front_default));
                    //Determinamos el tipo de pokemon que es
                    getType(pokemon.types[0].type.name);
                }
            } catch (Exception e) {
                MessageBox.Show("El pokemon no existe");
            }
         }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Recupero el nombre del pokemon
            pokemon = textBox.Text;
            recuperarDatoConcreto();
        }

        //Funcion para indicar en el color del marco de que tipo es el pokemon
        private void getType(String tipo)
        {
            switch (tipo)
            {
                case "fire":
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.Red);
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    
                    break;
                case "fairy":
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.Purple);
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    
                    break;
                case "water":
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.Blue);
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    
                    break;
                case "steel":
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.Gray);
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    
                    break;
                case "bug":
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.LightSeaGreen);
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    
                    break;
                case "dragon":
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.Aquamarine);
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    
                    break;
                case "electric":
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.Yellow);
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    
                    break;
                case "ghost":
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.LightPink);
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    
                    break;
                case "ice":
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.Snow);
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    
                    break;
                case "normal":
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.Coral);
                    
                    break;
                case "grass":
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.Green);
                    
                    break;
                case "psychic":
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.DarkViolet);
                   
                    break;
                case "rock":
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.Brown);
                    
                    break;
                case "sinister":
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.BlueViolet);
                    
                    break;
                case "ground":
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.RosyBrown);
                    
                    break;
                case "poison":
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.MediumPurple);
                    
                    break;
                case "flying":
                    BordeImagen.CornerRadius = new CornerRadius(7);
                    BordeImagen.BorderBrush = new SolidColorBrush(Colors.AliceBlue);
                        break;
            }
        }
    }
 }

