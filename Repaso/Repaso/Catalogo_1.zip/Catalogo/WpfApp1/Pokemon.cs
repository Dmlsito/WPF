﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class Pokemon
    {

       public int id { get; set; }
       public String name { get; set; }
       public int base_experience { get; set; }
       public int height { get; set; }
       public bool is_Default { get; set; }
       public int order { get; set; }
       public int weight { get; set; }
       public Sprite sprites { get; set; }
       public List <Generacion> types { get; set; }
    }
}
